=== Plugin Name ===
Tags: da, directadmin, dashboard, stats, charts, diskspace, bandwidth
Requires at least: 4.0
Stable tag: 1.0.2
Tested up to: 4.9.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Show bandwidth and disk usage stats from a DirectAdmin user on the users Wordpress dashboard

== Description ==

This plugin makes a connection to a server with DirectAdmin API enabled.
After the connection it reads the data usage from a DirectAdmin user and shows the usage in charts on the users Wordpress dashboard.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/directadmin-dashboard` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings -> DA Settings to configure the plugin
1. Host: Your domain with DirectAdmin installed on port :2222. If your website is on https replace https:// with: ssl://.
1. Username: Use your reselleraccount username if you want setup multiple users in one Wordpress installation with a DirectAdmin Dashboard.
1. Password: Make a seperate login key in DirectAdmin and fill in the password (http://help.directadmin.com/item.php?id=523). I don't recommend using your DirectAdmin password.
1. Edit a Wordpress user and fill in the DirectAdmin username (bottom)
1. The user now can view the stats on the dashboard page

== Screenshots ==

1. Dashboard widget
2. Settings

== Frequently Asked Questions ==

= Q. I have a question =
 A. Chances are, someone else has asked it. Check out the support forum.

== Changelog ==
= 1.0.2=
* Tested up to 4.9.1

= 1.0.1=
* Small cleanup

= 1.0 =
* DirectAdmin Dashboard