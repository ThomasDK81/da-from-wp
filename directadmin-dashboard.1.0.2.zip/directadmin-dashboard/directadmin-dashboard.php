<?php
/**
 * Plugin Name: DirectAdmin Dashboard
 * Plugin URI: https://wielands.nl
 * Description: Show the user bandwidth and disk usage on the users dashboard
 * Version: 1.0.2
 * Author: Wieland Vernooij
 * Author URI: https://wielands.nl
 * Text Domain: da_wp
 */

if ( ! defined( 'ABSPATH' ) ) {
    die( '-1' );
}

/**
 * Plugin Load
 * ============================================================================== */
class DaAdmin_WP
{
    public $version;
    public $plugin_base;

    public function __construct() {
        $this->plugin_name = DA_WP_NAME;
        $this->version = '1.0.2';
        $this->plugin_base = plugin_basename(__FILE__);

        $this->plugin_hooks();
        $this->plugin_filters();
    }

    public static function plugin_activate() {

    }

    public static function plugin_deactivate() {

    }

    public function plugin_hooks() {
        add_action( 'admin_init', array( &$this, 'admin_init' ) );
        add_action( 'admin_menu', array( &$this, 'add_plugin_menu' ) );
        add_action( 'plugins_loaded', array( &$this, 'add_plugin_language') );
    }

    public function plugin_filters() {
        add_filter( 'plugin_action_links_'.$this->plugin_base, array( &$this, 'plugin_settings_link' ));
    }


    public function admin_init() {
        // Set up the settings for this plugin
        $this->init_settings();
        // Possibly do additional admin_init tasks
    }

    public function add_plugin_menu() {
        add_options_page( __( 'Settings', DA_WP_NAME ), __( 'DA Settings', DA_WP_NAME ), 'manage_options', $this->plugin_name, array( &$this, 'plugin_settings_page' ) );
    }

    public function add_plugin_language() {
        load_plugin_textdomain( 'da_wp', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
    }

    public function init_settings() {
        // add your settings section
        add_settings_section(
            $this->plugin_name.'_da_settings',
            __( 'DirectAdmin settings', DA_WP_NAME ),
            array(&$this, 'settings_section_callback'),
            $this->plugin_name
        );

        // add your setting's fields
        add_settings_field(
            $this->plugin_name.'_setting_host',
            __( 'Host', DA_WP_NAME ),
            array(&$this, 'settings_field_input_text'),
            $this->plugin_name,
            'da_wp_da_settings',
            array(
                'field' => $this->plugin_name.'_host'
            )
        );

        add_settings_field(
            $this->plugin_name.'_setting_user',
            __( 'Username', DA_WP_NAME ),
            array(&$this, 'settings_field_input_text'),
            $this->plugin_name,
            'da_wp_da_settings',
            array(
                'field' => $this->plugin_name.'_user'
            )
        );

        add_settings_field(
            $this->plugin_name.'_setting_password',
            __( 'Password' , DA_WP_NAME ),
            array(&$this, 'settings_field_input_text'),
            $this->plugin_name,
            'da_wp_da_settings',
            array(
                'type'  => 'password',
                'field' => $this->plugin_name.'_password'
            )
        );

        // register the settings for this plugin
        register_setting( $this->plugin_name, $this->plugin_name.'_host' );
        register_setting( $this->plugin_name, $this->plugin_name.'_user' );
        register_setting( $this->plugin_name, $this->plugin_name.'_password' );
    }

    public function settings_section_callback() {
        echo __( 'Please fill in your reseller DirectAdmin settings', DA_WP_NAME );
    }

    public function settings_field_input_text( $args ) {
        // Get the field name from the $args array
        $field = $args['field'];

        if( isset( $args['type'] ) ) {
            $field_type = $args['type'];
        }
        else {
            $field_type = 'text';
        }
        // Get the value of this setting
        $value = get_option($field);
        // echo a proper input type="text"
        echo sprintf('<input type="%s" name="%s" id="%s" value="%s" />', $field_type, $field, $field, $value);
    }

    // Add the settings link to the plugins page
    public function plugin_settings_link( $links ) {
        $settings_link = '<a href="options-general.php?page='.$this->plugin_name.'">'.__( 'Settings', DA_WP_NAME ).'</a>';
        array_unshift( $links, $settings_link );
        return $links;
    }

    public function plugin_settings_page() {
        if( !current_user_can('manage_options') )
        {
            wp_die( __('You do not have sufficient permissions to access this page.') );
        }

        // Render the settings template
        include dirname(__FILE__).'/templates/settings.php';
    }
}

if( class_exists( 'DaAdmin_WP' ) ) {
    define( 'DA_WP_NAME', 'da_wp');
    define( 'DA_PLUGIN_URL', dirname(__FILE__) );
    define( 'DA_PLUGIN_MAIN_URL', plugin_dir_url(__FILE__ ) );

    require_once 'classes/da-api.php';
    require_once 'classes/da-wp-user.php';

    register_activation_hook(__FILE__, array('DaAdmin_WP', 'plugin_activate'));
    register_deactivation_hook(__FILE__, array('DaAdmin_WP', 'plugin_deactivate'));

    // Run plugin
    new DaAdmin_WP();
    new DaAdmin_User_WP();
}