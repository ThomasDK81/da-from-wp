<?php
class DaAdmin_User_WP
{
    public function __construct() {
        $this->plugin_name = DA_WP_NAME;
        $this->user_hooks();
    }

    public function user_hooks() {
        // Load scripts
        add_action( 'admin_enqueue_scripts', array( &$this, 'load_scripts' ) );

        // Add dashboard widget
        add_action( 'wp_dashboard_setup', array( &$this, 'add_da_dashboard_widgets' ));

        // Show settings
        add_action( 'show_user_profile', array( &$this, 'user_da_fields' ) );
        add_action( 'edit_user_profile', array( &$this, 'user_da_fields' ) );

        // Save settings
        add_action( 'personal_options_update', array( &$this, 'user_save_da_settings') );
        add_action( 'edit_user_profile_update', array( &$this, 'user_save_da_settings') );
    }

    public function load_scripts( $hook ) {

        if( $hook != 'index.php' )
            return;

        wp_enqueue_script( 'da_charts', DA_PLUGIN_MAIN_URL . 'js/Chart.min.js' );
        wp_enqueue_style( 'da-charts', DA_PLUGIN_MAIN_URL . 'css/style.css' );
    }

    public function add_da_dashboard_widgets() {

        $current_user = wp_get_current_user();
        $da_username = get_the_author_meta( 'da_username', $current_user->ID );

        if( !empty ( $da_username ))
        {
            $da_api = new DaAdmin_API_WP();
            $data = $da_api->get_all_data( $da_username );

            if( !empty( $data )) {

                if( $data['package'] == 'custom') {
                    $package = '';
                }
                else {
                    $package = ': '.$data['package'];
                }
                add_meta_box('da_abo_dashboard_widget', __( 'My hostingpackage', DA_WP_NAME ) . $package, array( &$this, 'da_dashboard_widget'), 'dashboard', 'normal', 'high', $data );
            }
        }
    }

    public function da_dashboard_widget( $post, $data ) {
        include DA_PLUGIN_URL.'/templates/da-dashboard.php'; // HTML
    }


    public function user_da_fields( $user ) {
        ?>
        <h3><?php _e( 'DirectAdmin settings', DA_WP_NAME ); ?></h3>

        <table class="form-table">
            <tr>
                <th><label for="da_username"><?php _e( 'Username', DA_WP_NAME ); ?></label></th>
                <td><input type="text" name="da_username" value="<?php echo esc_attr( get_the_author_meta( 'da_username', $user->ID ) ); ?>" class="regular-text" /></td>
            </tr>
        </table>
        <?php
    }

    public function user_save_da_settings( $user_id ) {
        update_user_meta( $user_id, 'da_username', sanitize_text_field( $_POST['da_username'] ) );
    }
}