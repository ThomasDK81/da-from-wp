<?php
class DaAdmin_API_WP
{
    public $connect;

    public function __construct() {
        $this->plugin_name = DA_WP_NAME;

        $this->connect_api();
    }

    public function connect_api() {
        require_once DA_PLUGIN_URL.'/vendors/class-httpsocket.php';

        $da_ip = get_option( $this->plugin_name.'_host' );
        $da_user = get_option( $this->plugin_name.'_user' );
        $da_password = get_option( $this->plugin_name.'_password' );

        $socket = new HTTPSocket;
        $socket->connect( $da_ip, 2222 );
        $socket->set_login( $da_user, $da_password );

        $this->connect = $socket;
    }

    public function get_current_usage( $username ) {
        $data = '';

        $this->connect->set_method( 'GET' );

        // Get user stats
        $this->connect->query('/CMD_API_SHOW_USER_USAGE', array( 'user' => $username ));
        $user_current = $this->connect->fetch_parsed_body();

        if ( $this->connect->get_status_code() != 200 || !empty( $user_current['error'] ) )
        {
            $data['error'] = $user_current['error'];
        }
        else
        {
        	if( !isset( $user_current['bandwidth'] ) || !isset( $user_current['quota'] ) ) {
		        $data['error'] = 'API error';
	        } else {
	            $data['current_bandwidth'] = $user_current['bandwidth'];
	            $data['current_quota'] = $user_current['quota'];
	        }
        }

        return $data;
    }

    public function get_limit_usage( $username ) {
        $data = '';

        $this->connect->set_method( 'GET' );

        // Get user limits
        $this->connect->query('/CMD_API_SHOW_USER_CONFIG', array( 'user' => $username ));
        $user_limits = $this->connect->fetch_parsed_body();


        if ( $this->connect->get_status_code() != 200 || !empty( $user_limits['error'] ) )
        {
            $data['error'] = $user_limits['error'];
        }
        else
        {
	        if( !isset( $user_limits['bandwidth'] ) || !isset( $user_limits['quota'] ) ) {
		        $data['error'] = 'API error';
	        } else {
	            $data['package'] = $user_limits['package'];
	            $data['limit_bandwidth'] = $user_limits['bandwidth'];
	            $data['limit_quota'] = $user_limits['quota'];
	        }

        }

        return $data;
    }

    public function get_all_data( $da_username ) {
        $data_current = $this->get_current_usage( $da_username );
        $data_limit = $this->get_limit_usage( $da_username );

        $data = array_merge($data_current, $data_limit);

        return $data;
    }
}