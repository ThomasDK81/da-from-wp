<div class="da-data-stats">
    <h3><?php _e( 'Diskspace', DA_WP_NAME ); ?></h3>
    <div id="canvas-holder">
        <canvas id="chart-disk" width="300" height="300"/>
    </div>

    <div id="legend-disk" class="chart-legend"></div>
</div>

<div class="da-disk-stats">
    <h3><?php _e( 'Bandwidth', DA_WP_NAME ); ?></h3>
    <div id="canvas-holder">
        <canvas id="chart-data" width="300" height="300"/>
    </div>

    <div id="legend-data" class="chart-legend"></div>
</div>

<?php
$data_disk_remaining = $data['args']['limit_quota'] - $data['args']['current_quota'];
$data_bandwidth_remaining = $data['args']['limit_bandwidth'] - $data['args']['current_bandwidth'];

if( $data_bandwidth_remaining < 0 ) {
    $data_bandwidth_remaining = 0;
}

if( $data_disk_remaining < 0 ) {
    $data_disk_remaining = 0;
}
?>
<ul class="da-limits">
    <li><?php _e( 'Bandwidth', DA_WP_NAME ); ?>: <strong><?php echo $data['args']['limit_bandwidth']; ?> MB</strong> <small><?php _e( 'per month', DA_WP_NAME ); ?></small></li>
    <li><?php _e( 'Diskspace', DA_WP_NAME ); ?>: <strong><?php echo $data['args']['limit_quota']; ?> MB</strong></li>
</ul>

<script>
    Chart.defaults.global.responsive = true;

    var data_disk = [
        {
            value: <?php echo $data['args']['current_quota']; ?>,
            color:"#114459",
            highlight: "#33728C",
            label: "<?php _e( 'Used', DA_WP_NAME ); ?>"
        },
        {
            value: <?php echo $data_disk_remaining; ?>,
            color: "#249b63",
            highlight: "#3DAD78",
            label: "<?php _e( 'Available', DA_WP_NAME ); ?>"
        }

    ];

    var data_bandwidth = [
        {
            value: <?php echo $data['args']['current_bandwidth']; ?>,
            color:"#114459",
            highlight: "#33728C",
            label: "<?php _e( 'Used', DA_WP_NAME ); ?>"
        },
        {
            value: <?php echo $data_bandwidth_remaining; ?>,
            color: "#9365c1",
            highlight: "#3DAD78",
            label: "<?php _e( 'Available', DA_WP_NAME ); ?>"
        }

    ];

    function load_data_chart() {
        var data_chart = document.getElementById("chart-data").getContext("2d");
        window.dataChart = new Chart(data_chart).Pie(data_bandwidth);

        document.getElementById('legend-data').innerHTML = window.dataChart.generateLegend();

    }
    function load_disk_chart() {
        var disk_chart = document.getElementById("chart-disk").getContext("2d");
        window.diskChart = new Chart(disk_chart).Pie(data_disk);

        document.getElementById('legend-disk').innerHTML = window.diskChart.generateLegend();
    }

    function da_load_charts() {
        load_data_chart();
        load_disk_chart();
    }
    window.onload = da_load_charts;
</script>
