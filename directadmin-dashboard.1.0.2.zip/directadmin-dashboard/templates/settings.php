<div class="wrap">

    <h2><?php echo esc_html( get_admin_page_title() ); ?></h2>

    <form method="post" name="da_wp_options" action="options.php">

        <?php
        settings_fields( $this->plugin_name );
        do_settings_sections( $this->plugin_name );
        ?>

        <?php submit_button( 'Save all changes', 'primary', 'submit', TRUE ); ?>

    </form>

</div>